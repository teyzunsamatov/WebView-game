КАК СОБРАТЬ APK ТОЛЬКО С ТЕЛЕФОНА

1. Создай пустой GitHub repository.
2. Распакуй этот ZIP на телефоне.
3. Загрузи ВСЕ файлы и папки в repository.
   В корне должны находиться:
   - app
   - .github
   - build.gradle
   - settings.gradle
   - gradle.properties
4. Открой GitHub -> Actions.
5. Выбери "Build APK".
6. Нажми "Run workflow".
7. После завершения открой выполненный workflow.
8. В разделе Artifacts скачай "webview-game-debug".
9. Внутри будет app-debug.apk.

Игра/страница запускается из:
app/src/main/assets/index.html
