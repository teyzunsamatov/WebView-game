WEBVIEW GAME ANDROID PROJECT

The HTML game/page is stored at:
app/src/main/assets/index.html

Main Android entry point:
app/src/main/java/com/example/webviewgame/MainActivity.java

The app opens index.html locally in Android WebView.

Build:
1. Open this folder as an Android Studio project.
2. Let Gradle sync.
3. Build > Build APK(s).

Important:
The supplied source file was recovered as HTML from the uploaded file.
This wrapper does not add game mechanics that are not present in the HTML.
